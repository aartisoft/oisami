<?php
require_once dirname(__FILE__).'/Google_Client.php';
require_once dirname(__FILE__).'/contrib/Google_Oauth2Service.php';
