<?php
/**
 *
 * Hooks
 *
 * @package   Listingo VC Core
 * @author    themographics
 * @link      https://themeforest.net/user/themographics/portfolio
 * 
 
 * @since 1.0
 */
