<?php 
/**
 * @Import Users
 * @return{}
 */     

if ( !class_exists('SP_Import_User') ) {    
    class SP_Import_User {        
        function __construct(){
            // Constructor Code here..
   		}
		
		/*
		 * @import users
		 */
		public function listingo_import_user(){
		
			global $wpdb, $wpdb_data_table;
		
			
		if ( ! defined( 'IS_IU_CSV_DELIMITER' ) )
			define ( 'IS_IU_CSV_DELIMITER', ',' );
	
			// User data fields list used to differentiate with user meta
			$userdata_fields       = array(
				'ID', 
				'username', 
				'user_pass',
				'user_email', 
				'user_url', 
				'user_nicename',
				'display_name', 
				'user_registered', 
				'first_name',
				'last_name', 
				'nickname', 
				'description',
				'rich_editing', 
				'comment_shortcuts', 
				'admin_color',
				'use_ssl', 
				'show_admin_bar_front', 
				'show_admin_bar_admin',
				'role'
			);

			$wp_user_table		= $wpdb->prefix.'users';
			$wp_usermeta_table	= $wpdb->prefix.'usermeta';
			
			if ( isset( $_FILES['users_csv']['tmp_name'] ) ) {
				$filename              = $_FILES['users_csv']['tmp_name'];
				$file_handle = fopen( $filename, 'r' );
			} else{
				$file_handle = fopen( ListingoGlobalSettings::get_plugin_path().'/import-users/users.csv', 'r' );
			}
			
			
			// Loop through the file lines
			$csv_reader = new ReadCSV( $file_handle, IS_IU_CSV_DELIMITER, "\xEF\xBB\xBF" ); // Skip any UTF-8 byte order mark.
	
			$first = true;
			$rkey = 0;
			while ( ( $line = $csv_reader->get_row() ) !== NULL ) {
	
				// If the first line is empty, abort
				// If another line is empty, just skip it
				if ( empty( $line ) ) {
					if ( $first )
						break;
					else
						continue;
				}
	
				// If we are on the first line, the columns are the headers
				if ( $first ) {
					$headers = $line;
					$first = false;
					continue;
				} else{
					$data = array_map("utf8_encode", $line); //Encoding other than english language
				}
	
				// Separate user data from meta
				$userdata = $usermeta = array();
				foreach ( $data as $ckey => $column ) {
					$column_name = $headers[$ckey];
					$column = trim( $column );
	
					if ( in_array( $column_name, $userdata_fields ) ) {
						$userdata[$column_name] = $column;
					} else {
						$usermeta[$column_name] = $column;
					}
				}
				
				// If no user data, bailout!
				if ( empty( $userdata ) )
					continue;
	
				// Something to be done before importing one user?
				//do_action( 'is_iu_pre_user_import', $userdata, $usermeta );
	
				$user = $user_id = false;
	
				if ( isset( $userdata['r_id'] ) ) {
					$user = get_user_by( 'ID', $userdata['r_id'] );
				}
	
				if ( ! $user ) {
					if ( isset( $userdata['username'] ) )
						$user = get_user_by( 'login', $userdata['username'] );
	
					if ( ! $user && isset( $userdata['user_email'] ) )
						$user = get_user_by( 'email', $userdata['user_email'] );
				}
				
				$update = false;
				if ( $user ) {
					$userdata['ID'] = $user->ID;
					$update = true;
				}
	
				// If creating a new user and no password was set, let auto-generate one!
				if ( ! $update && $update == false  && empty( $userdata['user_pass'] ) ) {
					$userdata['user_pass'] = wp_generate_password( 12, false );
				}
	
				/*if ( $update )
					$user_id = wp_update_user( $userdata );
				else
					$user_id = wp_insert_user( $userdata );*/
				
				if (isset($update)&& $update == true) {
					$userdata['ID']	= $usermeta['r_id'];
					//$sql = "UPDATE $wp_user_table SET VALUE=".$value_to_store." WHERE USER_ID=$wp_userid AND FIELD_ID=".$ef_details["ID"];
					$user_id = wp_update_user( $userdata );
				} else {
					
					$display_name	= '';
					if( $userdata['role'] === 'business' ){
						$display_name	= !empty( $userdata['username'] ) ? $userdata['username'] : '';
					} else{
						$display_name	= $userdata['first_name'].' '.$userdata['last_name'];
					}
					
					$sql = "INSERT INTO $wp_user_table (ID, 
														user_login, 
														user_pass, 
														user_email, 
														user_registered,
														user_status, 
														display_name, 
														user_nicename, 
														user_url
														) VALUES ('".$usermeta['r_id']."',
														'".$userdata['username']."',
														'".md5($userdata['user_pass'])."',
														'".$userdata['user_email']."',
														'".date('Y-m-d H:i:s')."',
														0,
														'".$display_name."',
														'".$userdata['username']."',
														'".$userdata['user_url']."'
													)";
					$wpdb->query($sql);
					$lastid = $wpdb->insert_id;
					$new_user = new WP_User( $lastid );
					
					if( $userdata['role'] === 'business' ){
						$new_user->set_role( 'business' );	
					} else{
						$new_user->set_role( 'professional' );	
					}

					$user_id =	$lastid;
					
					// Include again meta fields
					$usermeta['description']	= $userdata['description'];
					$usermeta['first_name']	    = $userdata['first_name'];
					$usermeta['last_name']	    = $userdata['last_name'];

					update_user_meta( $user_id, 'usertype', $userdata['role'] ); //update user type
					update_user_meta( $user_id, 'show_admin_bar_front', 'false' );
					update_user_meta( $user_id, 'full_name', $display_name );
					update_user_meta( $user_id, 'rich_editing', 'true' );
					update_user_meta( $user_id, 'nickname', $display_name );
					update_user_meta( $user_id, 'activation_status', 'active');
					
				}
				
				
				// Is there an error o_O?
				if ( is_wp_error( $user_id ) ) {
					$errors[$rkey] = $user_id;
				} else {
					// If no error, let's update the user meta too!
					$db_schedules	= array();
					if ( $usermeta ) {
						foreach ( $usermeta as $metakey => $metavalue ) {
							$metavalue = maybe_unserialize( $metavalue );

							//Privacy Settings
							if( $metakey == 'privacy' && !empty( $metavalue ) ){
								$awards	= array();
								$user_privacy	= explode('||',$metavalue);
								$user_privacy	= array_diff( $user_privacy, array('') );

								$db_user_privacy = array();
								$counter	= 0;
								foreach( $user_privacy as $key => $value ){
									$privacy_data	= explode(':',$value);
									if( !empty( $privacy_data[0] ) ) {
										$db_user_privacy[trim( $privacy_data[0])]	= trim( $privacy_data[1] ); 
										$counter++;
									}
								}

								update_user_meta( $user_id, $metakey, $db_user_privacy );
							} else if( $metakey == 'gallery' && !empty( $metavalue ) ){
								$user_gallery	= explode('|',$metavalue);
								$metakey	= 'profile_gallery_photos';
								$gallery_data	= array();
								$gallery_data['image_type']	= 'profile_gallery';
								$gallery_data['default_image']	= $user_gallery[0];
								
								foreach( $user_gallery as $key => $value ){
									$full = listingo_prepare_image_source($value, 0, 0);
									$thumbnail = listingo_prepare_image_source($value, 150, 150);
									
									$gallery_data['image_data'][$value]['full'] = $full;
									$gallery_data['image_data'][$value]['thumb']  = $thumbnail;
									$gallery_data['image_data'][$value]['banner']  = $full;
									$gallery_data['image_data'][$value]['image_id']  = $value;
								}

								update_user_meta( $user_id, $metakey, $gallery_data );
							} else if( $metakey == 'avatar' && !empty( $metavalue ) ){
								$user_gallery	= explode('|',$metavalue);
								$metakey	= 'profile_avatar';
								$gallery_data	= array();
								$gallery_data['image_type']	= 'profile_photo';
								$gallery_data['default_image']	= $user_gallery[0];
								
								foreach( $user_gallery as $key => $value ){
									$full = listingo_prepare_image_source($value, 0, 0);
									$thumbnail = listingo_prepare_image_source($value, 150, 150);
									
									$gallery_data['image_data'][$value]['full'] = $full;
									$gallery_data['image_data'][$value]['thumb']  = $thumbnail;
									$gallery_data['image_data'][$value]['banner']  = $full;
									$gallery_data['image_data'][$value]['image_id']  = $value;
								}

								update_user_meta( $user_id, $metakey, $gallery_data );
							} else{
								update_user_meta( $user_id, $metakey, trim( $metavalue ) );
							}	
							
						}
					
					}
	
					// If we created a new user, maybe set password nag and send new user notification?
					if ( ! $update ) {
					}
				}
	
				$rkey++;
			}
			
			fclose( $file_handle );
		}
	}
}