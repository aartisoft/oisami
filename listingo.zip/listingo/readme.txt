﻿=====Init Release : 08-09-2017=========

Please Install Required plugin and their extensions before use our theme

Please install following Plugins

-- Listingo Core
-- Loco Translate
-- Unyson
-- WoCoommerce
-- Contact Form 7

------ThemoGraphics--------

For more information you can contact us at our support forum : https://themographics.ticksy.com/