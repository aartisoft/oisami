Since Listingo Version 1.0

Author Themographics
Portfolio : https://themeforest.net/user/themographics/portfolio

====Package Include====
-[listingo.zip] Main Theme which include demo content and all plugins.
-[documentation] It include Theme documentation.
-[listingo-child] It include child theme for Listingo. Child theme is better to customize theme.-[plugins] It include all supporting plugins.





Filters***************************

Get number of year for experience

-- listingo_get_experience_years
-- listingo_get_career_levels
