<?php
/**
 *
 * Archive Page
 *
 * @package   Listingo
 * @author    themographics
 * @link      https://themeforest.net/user/themographics/portfolio
 * @since 1.0
 */
get_template_part("archive", "page");
?>