<?php

if (!defined('FW'))
    die('Forbidden');

$cfg = array(
    'page_builder' => array(
        'title' => esc_html__('SP Cities', 'listingo'),
        'description' => esc_html__('Display Cities.', 'listingo'),
        'tab' => esc_html__('Listingo', 'listingo'),
    )
);
