<?php

if (!defined('FW'))
    die('Forbidden');

$cfg = array(
    'page_builder' => array(
        'title' => __('Banner Slider', 'listingo'),
        'description' => __('Display slider.', 'listingo'),
        'tab' => __('Listingo', 'listingo'),
    )
);
