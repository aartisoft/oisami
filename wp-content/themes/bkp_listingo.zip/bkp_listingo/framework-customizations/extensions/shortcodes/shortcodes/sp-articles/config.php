<?php

if (!defined('FW'))
    die('Forbidden');

$cfg = array(
    'page_builder' => array(
        'title' => esc_html__('SP Articles', 'listingo'),
        'description' => esc_html__('Display articles written by providers.', 'listingo'),
        'tab' => esc_html__('Listingo', 'listingo'),
    )
);
