<?php if (!defined('FW')) die('Forbidden');
/**
 * @var string $uri Demo directory url
 */

$manifest = array();
$manifest['title'] = esc_html__('Listingo Unyson', 'listingo');
$manifest['screenshot'] = get_template_directory_uri(). '/demo-content/images/unyson.jpg';
$manifest['preview_link'] = 'https://themographics.com/wordpress/listingo/';