<?php

if (!defined('FW')) {
    die('Forbidden');
}
//
//$options = array(
//    'fw_ext_article_settings' => array(
//        'title' => false,
//        'type' => 'box',
//        'options' => array(
//            'fw_ext_article_listing' => array(
//                'label' => esc_html__('Article Listing Page.', 'listingo'),
//                'type' => 'multi-select',
//                'population' => 'posts',
//                'source' => 'page',
//                'desc' => esc_html__('Choose article listing page template.', 'listingo'),
//                'limit' => 1
//            ),
//        )
//    )
//);
