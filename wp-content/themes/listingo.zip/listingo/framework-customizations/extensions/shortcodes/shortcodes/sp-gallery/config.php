<?php

if (!defined('FW'))
    die('Forbidden');

$cfg = array(
    'page_builder' => array(
        'title' => esc_html__('Gallery', 'listingo'),
        'description' => esc_html__('Display gallery.', 'listingo'),
        'tab' => esc_html__('Listingo', 'listingo'),
    )
);
