<?php
/**
 *
 * Footer Page
 *
 * @package   Listingo
 * @author    themographics
 * @link      https://themeforest.net/user/themographics/portfolio
 * @since 1.0
 */
?>
<?php do_action('listingo_do_process_footers');?>
<?php wp_footer(); ?>
</body></html>