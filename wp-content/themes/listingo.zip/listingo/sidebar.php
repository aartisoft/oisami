<?php

/**
 *
 * Theme sidebar
 *
 * @package   Listingo
 * @author    themographics
 * @link      https://themeforest.net/user/themographics/portfolio
 * @since 1.0
 */
if (!is_active_sidebar('sidebar-1')) {
    return;
}
dynamic_sidebar('sidebar-1');
?>



